
# Monopoly BD

This is a Bangla version of the classic Monopoly board game built with Flutter. The game is designed to be played solo against an AI opponent.

## How to Run

```bash
flutter pub get
flutter run
```

## Features

- Offline gameplay with AI  
- Bengali text and themes
