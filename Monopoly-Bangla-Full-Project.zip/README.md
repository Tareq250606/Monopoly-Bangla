# Monopoly BD

This is a Bangla version of the classic Monopoly board game built with Flutter.

## How to Run

```bash
flutter pub get
flutter run
```

## Features

- Offline gameplay with AI
- Bengali text and themes
